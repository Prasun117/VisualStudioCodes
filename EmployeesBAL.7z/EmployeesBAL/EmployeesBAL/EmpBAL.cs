﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeesBAL
{
    public class EmpBAL
    {
        public int EmployeeID { get; set; }
        public string Password { get; set; }
        public string EmployeeFname { get; set; }
        public string EmployeeLname { get; set; }
        public string EmpType { get; set; }
        public string EmpLocation { get; set; }
        public string Email { get; set; }
        public string Notification { get; set; }
    }
}
