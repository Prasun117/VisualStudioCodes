﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookingTable
{
    public class BookingTableBAL
    {
        public int BookingID { get; set; }
        public int EmployeeID { get; set; }
        public int RoomID { get; set; }
        public DateTime BookingDate { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndDate { get; set; }
        public DateTime EndTime { get; set; }
        public string Location { get; set; }
        public string BookingStatus { get; set; }
    }
}
