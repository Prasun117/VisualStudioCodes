﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RoomFacilities
{
    public class RoomFacilitiesBAL
    {
        public string FaciltyType { get; set; }
        public string TableType { get; set; }
        public bool Videocon { get; set; }
        public bool Phonecon { get; set; }
        public bool WhiteBoard { get; set; }
        public bool FlipChart { get; set; }
        public bool Screen { get; set; }
        public bool Projector { get; set; }
        public bool Network { get; set; }
        public bool Internet { get; set; }
        public bool Machines { get; set; }


    }
}
