﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class RoomDetailsBAL
    {
        public int RoomID { get; set; }
        public string FacilityType { get; set; }
        public string RoomName { get; set; }

        public string RoomType { get; set; }
        public int RoomCapacity { get; set; }
        public string RoomLocation { get; set; }
        public int Coordinatorid { get; set; }
    }
}
